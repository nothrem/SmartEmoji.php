# EMOJI 12.1
This directory contains data files for UTS #51 Unicode Emoji, Version 12.1

This is a dot release that has some additional emoji ZWJ sequences, but is otherwise unchanged.

Version 12.1 is a data-only release, and does not make changes in UTS #51. Thus 
http://www.unicode.org/reports/tr51/tr51-16.html is still the corresponding specification.

For the 12.1 versions of the charts, see:
* http://unicode.org/emoji/charts-12.1/

For the 12.1 versions of the data, see:
* http://unicode.org/Public/emoji/12.1/emoji-data.txt
* http://unicode.org/Public/emoji/12.1/emoji-sequences.txt
* http://unicode.org/Public/emoji/12.1/emoji-variation-sequences.txt
* http://unicode.org/Public/emoji/12.1/emoji-zwj-sequences.txt
* http://unicode.org/Public/emoji/12.1/emoji-test.txt

This file is downloaded from https://unicode.org/Public/emoji/12.1/ReadMe.txt and updated to GitHub README.
